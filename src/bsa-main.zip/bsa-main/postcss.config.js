export const plugins = {
	tailwindcss: {}
};